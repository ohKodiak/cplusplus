#include <iostream>
#include <vector>
#include <string>
#include "Employee.h"
#include "HourlyEmployee.h"
using namespace std;

int main (int argc, char * argv[])
{
    HourlyEmployee h;
    cout << h << endl;

    return 0;
}